package com.youkeda.redpacket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedpacketApplicationTests {

	@Test
	void contextLoads() {
	}

}
