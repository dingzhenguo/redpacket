package com.youkeda.redpacket.model;

public enum PreSingleRedEnvelopeStatus {
    //未分配
    TODO,
    //已分配
    DONE
}
