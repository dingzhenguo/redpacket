package com.youkeda.redpacket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedpacketApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedpacketApplication.class, args);
    }

}