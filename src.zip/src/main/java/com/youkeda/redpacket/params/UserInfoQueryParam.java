package com.youkeda.redpacket.params;

import java.util.List;

public class UserInfoQueryParam {
    private List<String> idList;

    public List<String> getIdList() {
        return idList;
    }

    public void setIdList(List<String> idList) {
        this.idList = idList;
    }
}
